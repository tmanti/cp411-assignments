JobID: cp411-a4
Name: Thomas Ingram
ID: 200188260

Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Grade_Item_ID [self-evaluation/total/marker-evaluation] Description

A4

Q1 Culling, Lighting, Shading
Q1.1 [5/5/*] Concepts of culling                     
Q1.2 [5/5/*] Culling computing                       
Q1.3 [5/5/*] Concepts of lighting and shading        
Q1.4 [5/5/*] Lighting computing                      

Q2 OpenGL Culling, Lighting, Shading
Q2.1 [5/5/*] Hidden surface removal                  
Q2.2 [5/5/*] Lighting and shading                    
Q2.3 [0/0/*] Animation                               

Q3 SimpleView2 Culling, Lighting, Shading
Q3.1 [20/20/*] Culling                                 
Q3.2 [15/15/*] Lighting                                
Q3.3 [15/20/*] Shading                                 
Q3.4 [10/15/*] Animations                              

Total: [75/100/*]


