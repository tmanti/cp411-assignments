
Mesh object model file format

numVerts numNorms numFaces
list of vertices, one vertex per line: 
x y z
list of normals, one normal per line: 
x y z
list of face data, one face per three lines:
number_of_vertices_of_face
list of vertex index of the face
list of normal index at each vertex
