Name: Thomas Ingram
ID: 200188260
Email: ingr8826@mylaurier.ca
WorkID: cp411-a3
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols:  A - Assignment, Q - Question, T - Task
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If markers give different evaluation value, say 1, it will show 
[2/2/1] in the marking report. 

Question_ID [self-evaluation/total/marker-evaluation] Description

A3

Q1 Graphics transformations
Q1.1 [5/5/*] Principle of transformations            
Q1.2 [5/5/*] Hand on 2D transformations              
Q2 Graphics transformation programming
Q2.1 [5/5/*] Warm up C++                             
Q2.2 [5/5/*] 2D transformations                      
Q2.3 [5/5/*] 3D object and transformations           
Q2.4 [5/5/*] Mesh object model                       
Q3 SimpleView1 - transformations
Q3.1 [10/10/*] Create and render cube objects          
Q3.2 [10/10/*] Create and render the pyramid object    
Q3.3 [5/5/*] Create and render the house object      
Q3.4 [15/15/*] MCS transforms                          
Q3.5 [15/15/*] WCS transforms                          
Q3.6 [15/15/*] VCS transforms                          

Total: [100/100/*]

