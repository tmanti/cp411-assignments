# A3 Report

Author: Thomas Ingram 

Date: 2023/10/25 

Check [readme.txt](readme.txt) for course work statement and self-evaluation. 
  
## Q1 Graphics transformations (short_answer)


### Q1.1 Principle of transformations

### 1) What are the three basic transformations?

A:The three basic transformations are Translations, Scaling, and Rotations.

### 2) What is a composite transformation?

A: A composite transformation is a transformation performed on an object that consists of a sequence of the basic transformations.

### 3)Briefly describe why Homogeneous coordinate system is used in transformation computing.

A:The Homogeneous coordinate system is used in transformation computing because it allows us to treat all 3 different basic transformations in a consistent way. this is because it allows their matrix representations to be the same size and thus combinable. 

### Q1.2 Hand on 2D transformations

![image caption](images/a3q2.png){width=90%}

## Q2 Graphics transformation programming (lab practice)

### Q2.1 Warm up C++ 
Complete? Yes

![image caption](images/cppoop.png){width=90%}

### Q2.2 2D transformations 
Complete? Yes

![image caption](images/2dtrans.png){width=90%}

### Q2.3 3D object and transformations 
Complete? Yes

![image caption](images/3dtrans.png){width=90%}

### Q2.4 Mesh object model 
Complete? Yes

![image caption](images/meshtrans.png){width=90%}

## Q3 SimpleView1 - transformations (programming)


### Q3.1 Create and render cube objects 

Complete? Yes

![Rendering Cube Object](images/simpcube.png){width=90%}


### Q3.2 Create and render the pyramid object 

Complete? Yes

![Rendering Pyramid](images/simppyr.png){width=90%}


### Q3.3 Create and render the house object 

Complete? Yes

![Rendering House](images/simphouse.png){width=90%}


### Q3.4 MCS transforms 

Complete? Yes

![Scaled and MCS rotated cube](images/mcstrans.png){width=90%}


### Q3.5 WCS transforms 

Complete? Yes

![Translated and WCS rotated cube](images/wcstrans.png){width=90%}


### Q3.6 VCS transforms 

Complete? Yes 

![VCS rotation and translation of cube displaced](images/vcstrans.png){width=90%}

**References**

1. CP411 a3